﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define N_MAX 10///预先设定的n被允许的最大值，可根据需要更改
#define TURNCOLOR_purple printf("\033[35m")//运用宏定义使得更改颜色的操作可读性提高
#define TURNCOLOR_green_ printf("\033[32m")//同上，下同
#define TURNCOLOR_white_ printf("\033[0m")
#define TURNCOLOR_red___ printf("\033[31m")//注：最后的_只是用于对其，便于排版，益于阅读

void UpToDown(float Array[N_MAX][N_MAX * 2], int N_True);//从上到下的消元（消去“下三角”）
void DownToUp(float Array[N_MAX][N_MAX * 2], int N_True);//从下到上的消元（消去“上三角”）
int CalculateTheAnswer(float Array[N_MAX][N_MAX * 2], int N_True, float Answer[N_MAX][N_MAX]);//计算得到最终结果并将最终答案储存

int main(void)//原理：高斯若尔当消元法
{	/*
	基本思路:
	*首先需要用户输入一个n，表示需要输入一个n阶矩阵
	*需要注意的是，只有n*n矩阵才有逆矩阵
	*然后在这个矩阵右侧合并一个I（标准单位矩阵）
	*通过高斯消元将左侧的原矩阵化为I（标准单位矩阵），右侧矩阵最终的结果就是所需要的逆矩阵
	*/
	int n=0;//用户需要输入的n
	float Number[N_MAX][N_MAX * 2] = { 0 };//定义用于储存两个矩阵的二维数组，所以要乘2
	float Ans[N_MAX][N_MAX] = { 0 };//定义用于储存答案（所得逆矩阵）的二维数组

WrongInputToRestart://如果输入的n不在允许的范围内，则跳回这里

	TURNCOLOR_purple;printf(">");
	TURNCOLOR_green_;printf("Please input the size you want(n=):");
	TURNCOLOR_white_;
	scanf("%d", &n);//以上输出语句提示用户输入n，并读取用户输入的n

	if (n >= 1 && n <= N_MAX)
	{
		TURNCOLOR_purple; printf(">");
		TURNCOLOR_green_; printf("Please input n*n matrix.\n");
		TURNCOLOR_white_;
		int i, j;
		for (i = 0; i < n; i++)
			for (j = 0; j < n; j++)
				scanf("%f", &Number[i][j]);//读取原矩阵
		printf("\n");

		for (i = n; i < 2 * n; i++)
			Number[i - n][i] = 1;//添加右半部分n*n的单位矩阵

		//接下来进行处理并得出答案
		UpToDown(Number, n);//从上到下消元，消去对角线下方的三角形
		DownToUp(Number, n);//从下到上消元，消去对角线上方的三角形
		if (CalculateTheAnswer(Number, n, Ans) == 1)//计算最终结果
		{//输出运算结果
			TURNCOLOR_purple; printf(">");
			TURNCOLOR_green_; printf("The answer of this matrix:\n");
			TURNCOLOR_white_;
			for (i = 0; i < n; i++)
			{
				for (j = 0; j < n; j++)
					printf("%0.4f ", Ans[i][j]);
				printf("\n");
			}
			printf("\n");
		}
		else 
		{//告知用户其输入的矩阵没有对应的逆矩阵
			TURNCOLOR_purple; printf(">");
			TURNCOLOR_red___; printf("There is no answer for this matrix.\n\n");
			TURNCOLOR_white_;
		}
	}
	else
	{
		TURNCOLOR_purple; printf(">");
		TURNCOLOR_red___; printf("Your input(%d) is not allowed!\n",n);
		TURNCOLOR_purple; printf(">");
		TURNCOLOR_red___; printf("Please input from 1 to %d.\n",N_MAX);//提示用户输入错误并告知其允许的范围
		goto WrongInputToRestart;//跳转回去让用户重新输入
	}
	return 0;
}

void UpToDown(float Array[N_MAX][N_MAX * 2], int N_True)
{//从上往下消元
	///Array储存原矩阵与单位矩阵，N_True储存确定的大小（N_True阶矩阵）
	int i, j, k;//循环参数
	double Rate;//消元用的中介比例

	for (i = 0; i < N_True - 1; i++)//定:要消去Array[i][i]下方的元素,注意这里定的是第二维度
		for (j = i + 1; j < N_True; j++)//定：要消哪一行（第一维度从i+1遍历到n-1）
			if (Array[j][i] != 0)//需要消去的元素本身不为0才需要进行运算
			{
				Rate = (double)Array[j][i] / Array[i][i];
				for (k = 0; k < 2 * N_True; k++)
					Array[j][k] -= (float)(Rate*Array[i][k]);//一行内的每个元素都要进行操作且为平行操作
			}//“下三角”已被消去
	return;
}

void DownToUp(float Array[N_MAX][N_MAX * 2], int N_True)
{//从下往上消元
	///Array储存原矩阵与单位矩阵，N_True储存确定的大小（N_True阶矩阵）
	int i, j, k;//循环参数
	double Rate;//消元用的中介比例

	for (i = N_True - 1; i >= 0; i--)//定:要消去Array[i][i]上方的元素,注意这里定的是第二维度
		for (j = i - 1; j >= 0; j--)//定：要消哪一行（第一维度从i-1遍历到0）
			if (Array[j][i] != 0)//需要消去的元素本身不为0才需要进行运算
			{
				Rate = (double)Array[j][i] / Array[i][i];
				for (k = 0; k < 2 * N_True; k++)
					Array[j][k] -= (float)(Rate*Array[i][k]);//一行内的每个元素都要进行操作且为平行操作
			}//“上三角”已被消去
	return;
}

int CalculateTheAnswer(float Array[N_MAX][N_MAX * 2], int N_True, float Answer[N_MAX][N_MAX])
{//计算得到最总的逆矩阵
	///Array储存原矩阵与单位矩阵，N_True储存确定的大小（N_True阶矩阵）,Answer储存得到的逆矩阵
	_Bool HasSolution = 1;//记录矩阵是否有逆矩阵，1则有解0则无解
	int i, j;//循环参数

	//接下来进行计算，需要让矩阵左半部分变为标准矩阵
	//如果出现了某一行全部为0的情况，则说明矩阵没有逆矩阵
	//那么将HasSolution赋值为0
	//最终将HasSolution返回
	for (i = 0; i < N_True; i++)//因为只有一条对角线还有数值，只用判断对角线上是否有0即可
		if (Array[i][i] == 0)//如果这条对角线出现了0，则说明该矩阵没有逆矩阵
		{
			HasSolution = 0;//别忘了这个是要返回返回值的
			goto HasNoSolution;//直接跳过中间计算逆矩阵最后的步骤
		}

	//接下来将右侧矩阵除以左侧对角线对应系数就可以得到逆矩阵
	//并将右侧矩阵单独提出存入另一个二维数组
	for (i=0;i<N_True;i++)
		for (j = N_True; j < 2 * N_True; j++)
			Answer[i][j - N_True] = Array[i][j] / Array[i][i];//因为前面出现0的情况跳过了这里，所以不用考虑分母为0的情况

HasNoSolution://如果没有逆矩阵就跳到这里，跳过计算逆矩阵最后的步骤
	return (int)HasSolution;//将强制转化后的HasSolution返回（其实可以直接使函数返回值为_Bool）
}